from setuptools import setup, find_packages

setup(
    name="DimenCalc",
    version="1.0.0",
    description="A Python library for calculating area, volume, and perimeter of shapes and objects",
    author="Your Name",
    packages=find_packages(),  # Automatically finds all packages in the directory
    install_requires=[],  # Add any dependencies here
)
