import math

class Sphere:
    def __init__(self, radius):
        self.radius = radius

    def volume(self):
        return 4/3 * math.pi * self.radius ** 3

    def surface_area(self):
        return 4 * math.pi * self.radius ** 2

class Cube:
    def __init__(self, side):
        self.side = side

    def volume(self):
        return self.side ** 3

    def surface_area(self):
        return 6 * (self.side ** 2)

# Add more solids like Cylinder, Cone, etc.
